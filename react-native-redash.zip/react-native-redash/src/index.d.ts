declare module "parse-svg-path";
declare module "abs-svg-path";
declare module "normalize-svg-path";
