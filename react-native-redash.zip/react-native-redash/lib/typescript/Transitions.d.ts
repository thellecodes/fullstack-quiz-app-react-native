import Animated from "react-native-reanimated";
import { State } from "react-native-gesture-handler";
import { SpringConfig, TimingConfig } from "./Animations";
export declare const withTransition: (value: Animated.Node<number>, timingConfig?: TimingConfig, gestureState?: Animated.Value<State>) => Animated.Node<number>;
export declare const withSpringTransition: (value: Animated.Node<number>, springConfig?: SpringConfig, velocity?: Animated.Adaptable<number>, gestureState?: Animated.Value<State>) => Animated.Node<number>;
export declare const withTimingTransition: (value: Animated.Node<number>, timingConfig?: TimingConfig, gestureState?: Animated.Value<State>) => Animated.Node<number>;
export declare const useTransition: (state: boolean | number, config?: TimingConfig) => Animated.Node<number>;
export declare const useSpringTransition: (state: boolean | number, config?: SpringConfig) => Animated.Node<number>;
export declare const useTimingTransition: (state: boolean | number, config?: TimingConfig) => Animated.Node<number>;
