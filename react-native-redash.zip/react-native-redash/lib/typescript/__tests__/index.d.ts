import "./Coordinates.test";
import "./Math.test";
import "./Colors.test";
import "./Vectors.test";
import "./Matrix.test";
import "./Animations.test";
